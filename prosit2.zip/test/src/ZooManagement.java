
 import java.util.Scanner;

        public class ZooManagement {
            public static void main(String[] args) {

                //int nbrCages=20;
                //String zooName = "my zoo";

                Scanner sc = new Scanner(System.in);

                System.out.print("Nom du zoo : ");
                String zooName = sc.nextLine().trim();

                System.out.print("Ville du zoo : ");
                String city = sc.nextLine().trim();

                int nbrCages;
                do {
                    System.out.print("Nombre de cages : ");
                    while(!sc.hasNextInt()) {
                        System.out.println("Erreur : entrez un entier positif");
                        sc.next();
                    }
                    nbrCages = sc.nextInt();
                } while(nbrCages <= 0);

                Zoo myZoo = new Zoo(zooName, city, nbrCages);

                sc.nextLine();
                String choix;
                do {
                    System.out.print("Nom de l'animal : ");
                    String name = sc.nextLine();

                    System.out.print("Famille : ");
                    String family = sc.nextLine();

                    System.out.print("Age : ");
                    int age = sc.nextInt();

                    System.out.print("Mammifère (true/false) : ");
                    boolean isMammal = sc.nextBoolean();
                    sc.nextLine();

                    System.out.print("Ajouter un autre a nimal ? (oui/non) : ");
                    choix = sc.nextLine().trim().toLowerCase();
                } while(choix.equals("oui"));

                System.out.println("\nInformations du zoo");
                myZoo.displayZoo();

                System.out.println("------------:");
                System.out.println(myZoo);

                sc.close();
            }
        }
