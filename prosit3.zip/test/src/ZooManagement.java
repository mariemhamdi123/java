public class ZooManagement {
    public static void main(String[] args) {
        // Création d’animaux
        Animal lion = new Animal("Félidé", "Lion", 5, true);
        Animal tigre = new Animal("Félidé", "Tigre", 4, true);
        Animal crocodile = new Animal("Reptile", "Crocodile", 12, false);


        Zoo myZoo = new Zoo("Parc Animalier", "Tunis");
        Zoo otherZoo = new Zoo("Zoo National", "Sousse");


        myZoo.addAnimal(lion);
        myZoo.addAnimal(tigre);
        myZoo.addAnimal(crocodile);
        myZoo.addAnimal(lion);


        myZoo.displayZoo();
        myZoo.displayAnimals();

        System.out.println("Recherche Lion : " + myZoo.searchAnimal(lion));
        Animal lion2 = new Animal("Félidé", "Lion", 5, true);
        System.out.println("Recherche Lion2 : " + myZoo.searchAnimal(lion2));

        System.out.println("Suppression Tigre : " + myZoo.removeAnimal(tigre));
        myZoo.displayAnimals();

        otherZoo.addAnimal(new Animal("Canidé", "Chacal", 3, true));
        Zoo bigger = Zoo.comparerZoo(myZoo, otherZoo);
        System.out.println("Le zoo avec le plus d’animaux est : " + bigger.name);
    }
}
